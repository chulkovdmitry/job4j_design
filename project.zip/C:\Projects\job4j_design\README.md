
[![Build Status](https://travis-ci.com/chulkovdmitry/job4j_design.svg?branch=master)]
[![codecov](https://codecov.io/gh/chulkovdmitry/job4j_design/branch/master/graph/badge.svg?token=872WC4F8TT)](https://codecov.io/gh/chulkovdmitry/job4j_design)

#job4j_design
